import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;



public class BigNumArithmetic {
    public static void main(String[] args) throws IOException {
        FileInputStream file = new FileInputStream(args[0]);
        Scanner input = new Scanner(file);
        String line = input.nextLine();
        LList list = new LList();
        AStack nums = new AStack();
        String str = "";
        String updater = "";
        Object num1;
        Object num2;
        String p1;
        String p2;
        int op1;
        int op2;

        String[] arr = line.split("\\s+");
        for (int i = 0; i < arr.length; i++){
            String number = arr[i];
            if (!number.equals("+") && !number.equals("*") && !number.equals("^")) {
                nums.push(number);
            }
            if(number.equals("+") || number.equals("*") || number.equals("^")){
                num1 = nums.pop();
                num2 = nums.pop();
                String op = number;
                switch (op) {
                    case "+":
                        p1 = num1.toString();
                        p2 = num2.toString();
                        Object add = addition.addition(p1, p2);
                        nums.push(add);
                        break;
                    case "*":
                        p1 = num1.toString();
                        p2 = num2.toString();
                        //multiply m = new multiply();
                        //Object mult = m.multiply(p1, p2);
                        //nums.push(mult);
                        break;
                    case "^":
                        num1 = nums.pop();
                        num2 = nums.pop();
                        p1 = num1.toString();
                        op1 = Integer.parseInt(p1);
                        p2 = num2.toString();
                        op2 = Integer.parseInt(p2);
                        if (op2 < 0) {
                            op1 = 1 / op1;
                            op2 = -op2;
                        }
                        if (op2 == 0) {
                        }
                        int y = 1;
                        if (op2 % 2 == 0) {
                            op1 = op1 * op1;
                            op2 = op2 / 2;
                        } else {
                            y = op1 * y;
                            op1 = op1 * op1;
                            op2 = (op2 - 1) / 2;
                        }
                        int exp = op1 * y;
                        nums.push(exp);
                        break;

                }
            }


        }







        file.close();
        PrintWriter output = new PrintWriter("output.txt");
        Object get;
        String putout;
        for(int i = 0; i < nums.length(); i++){
            get = nums.pop();
            putout = get.toString();
            output.print(putout);
        }
        output.close();




    }

    public static class multiply{
        public multiply(String a, String b) {
            Object num1;
            Object num2;
            String s1;
            String s2;
            int n1;
            int n2;
            int carry = 0;
            int number = 0;
            int product = 0;
            LList L1 = stringToLL.stringToLL(a);
            LList L2 = stringToLL.stringToLL(b);
            LList pList = new LList();
            if(L1.length() == L2.length()){
                while(!L1.isAtEnd()){
                    num1 = L1.getValue();
                    s1 = num1.toString();
                    n1 = Integer.parseInt(s1);
                    num2 = L2.getValue();
                    s2 = num2.toString();
                    n2 = Integer.parseInt(s2);
                    number = n1 * n2 + carry;
                    carry = number / 10;
                }
            }
        }

    }

    public class addition{
        static String addition(String a, String b) {
            Object num1;
            Object num2;
            String s1;
            String s2;
            int n1;
            int n2;
            LList L1 = stringToLL.stringToLL(a);
            LList L2 = stringToLL.stringToLL(b);
            LList output = new LList();
            int carry = 0;
            int sum = 0;
            int number = 0;
            String out = "";
            if(L1.length() == L2.length()){
                while (!L1.isAtEnd()){
                    num1 = L1.getValue();
                    s1 = num1.toString();
                    n1 = Integer.parseInt(s1);
                    num2 = L2.getValue();
                    s2 = num2.toString();
                    n2 = Integer.parseInt(s2);
                    number = n1 + n2 + carry;
                    carry = number / 10;
                    sum = number % 10;
                    output.insert(sum);

                    L1.next();
                    L2.next();

                }
                out = LLtoString.LLtoString(output);

            } else if(L1.length() > L2.length()) {
                int diff = L1.length() - L2.length();
                int i = 0;
                while (i < diff) {
                    L2.append("0");
                    i++;
                }
                while (!L1.isAtEnd()) {
                    num1 = L1.getValue();
                    s1 = num1.toString();
                    n1 = Integer.parseInt(s1);
                    num2 = L2.getValue();
                    s2 = num2.toString();
                    n2 = Integer.parseInt(s2);
                    number = n1 + n2 + carry;
                    carry = number / 10;
                    sum = number % 10;
                    output.insert(sum);

                    L1.next();
                    L2.next();
                }
                out = LLtoString.LLtoString(output);

            } else if(L2.length() > L1.length()){
                int diff = L2.length() - L1.length();
                int i = 0;
                while (i < diff) {
                    L1.append("0");
                    i++;
                }
                while (!L1.isAtEnd()) {
                    num1 = L1.getValue();
                    s1 = num1.toString();
                    n1 = Integer.parseInt(s1);
                    num2 = L2.getValue();
                    s2 = num2.toString();
                    n2 = Integer.parseInt(s2);
                    number = n1 + n2 + carry;
                    carry = number / 10;
                    sum = number % 10;
                    output.insert(sum);

                    L1.next();
                    L2.next();
                }
                out = LLtoString.LLtoString(output);

            }
            return out;





        }
    }

    public class stringToLL{
        public static LList stringToLL(String a){
            LList list = new LList();
            for(int i = 0; i < a.length(); i++){
                char c = a.charAt(i);
                list.insert(c);

            }
            return list;
        }

    }

    public class LLtoString{
        public static String LLtoString(LList list){
            list.moveToStart();
            String string = "";
            for(int i = 0; i < list.length(); i++){
                Object x = list.getValue();
                string += x;
                list.next();
            }
            return string;
        }
    }

}







